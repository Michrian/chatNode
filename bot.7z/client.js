$(document).ready(function(){

    var socket = io('http://localhost:8000');

    
 $('#loginForm').submit(function(event){

   event.preventDefault();

    socket.emit('chat', {
        nom : $('#nom').val(),
        text : $('#text').val()
    });
    
    socket.on('retour', function(user){

        $('#message').append('<p>'+user.nom+'</p>');
       
    })

 });


   





  });