var app =require('express');
 var httpServer= require('http').createServer(function(req,res){
   //console.log("serveur en marche");
 });




 
var io= require('socket.io').listen(httpServer);

io.on('connection', function (socket) {
 // console.log(socket);

var me;
        socket.on('chat',function(user){


           io.sockets.emit('retour', user); 
        });

        
});




httpServer.listen('8000');
